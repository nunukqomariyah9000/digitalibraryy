<?php 
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
// koneksi database
include '../koneksi.php';
   
// menangkap data yang di kirim dari form
$KategoribukuID = $_POST['KategoribukuID'];
$BukuID = $_POST['BukuID'];
$KategoriID = $_POST['KategoriID'];
 
// menginput data ke database
// mysqli_query($koneksi,"update kategoribuku_relasi set BukuID='$BukuID', KategoriID='$KategoriID' where KategoriBukuID='$KategoribukuID'");
if (!$koneksi -> query("update kategoribuku_relasi set BukuID='$BukuID', KategoriID='$KategoriID' where KategoriBukuID='$KategoribukuID'")) {
    echo("Error description: " . $koneksi -> error);
  }
// mengalihkan halaman kembali ke kategori.php
header("location:koleksi.php?pesan=update");
 
?>