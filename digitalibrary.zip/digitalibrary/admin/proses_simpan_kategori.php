<?php 
// koneksi database
include '../koneksi.php';
 
// menangkap data yang di kirim dari form
$Namakategori = $_POST['Namakategori'];
 
// menginput data ke database
mysqli_query($koneksi,"insert into kategoribuku values('0','$Namakategori')");
 
// mengalihkan halaman kembali ke index.php
header("location:kategori.php?pesan=simpan");
 
?>