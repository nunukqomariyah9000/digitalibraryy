<?php
                include 'header.php';
                include 'navbar.php';
                ?>  
                <div class="contet mt-3">
                    <div class="row">
                        <div class="col-sm-3">
                            <div class="card">
                                <div class="card-body bg-warning text-center">
                                    <h3>Data buku</h3>
                                    <?php
                                    include '../koneksi.php';
                                    $data_buku = mysqli_query($koneksi,"SELECT * FROM buku");
                                    $jumlah_buku = mysqli_num_rows($data_buku);
                                    ?>
                                    <h3><?php echo $jumlah_buku; ?><h3>
                                    <br>
                                    <a href="buku.php" class="btn btn-dark btn-sm">Lihat data</a>
                                </div>
                                </div>
                            </div>
                            <div class="col-sm-3">
                            <div class="card">
                                <div class="card-body bg-danger text-center">
                                    <h3>Kategori Buku</h3>
                                    <?php
                                    include '../koneksi.php';
                                    $data_kategoribuku = mysqli_query($koneksi,"SELECT * FROM kategoribuku");
                                    $jumlah_kategoribuku = mysqli_num_rows($data_kategoribuku);
                                    ?>
                                    <h3><?php echo $jumlah_kategoribuku; ?><h3>
                                    <br>
                                    <a href="kategori.php" class="btn btn-dark btn-sm">Lihat data</a>
                                </div>
                                </div>
                            </div>
                            <div class="col-sm-3">
                            <div class="card">
                                <div class="card-body bg-info text-center">
                                    <h3>Users</h3>
                                    <?php
                                    include '../koneksi.php';
                                    $data_user = mysqli_query($koneksi,"SELECT * FROM user");
                                    $jumlah_user = mysqli_num_rows($data_user);
                                    ?>
                                    <h3><?php echo $jumlah_user; ?><h3>
                                    <br>
                                    <a href="users.php" class="btn btn-dark btn-sm">Lihat data</a>
                                </div>
                                </div>
                            </div>
                            <div class="col-sm-3">
                            <div class="card">
                                <div class="card-body bg-primary text-center">
                                    <h3>Peminjaman</h3>
                                    <?php
                                    include '../koneksi.php';
                                    $data_peminjaman = mysqli_query($koneksi,"SELECT * FROM peminjaman");
                                    $jumlah_peminjaman= mysqli_num_rows($data_peminjaman);
                                    ?>
                                    <h3><?php echo $jumlah_peminjaman; ?><h3>
                                    <br>
                                    <a href="laporan_peminjaman.php" class="btn btn-dark btn-sm">Lihat data</a>
                                </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
                <div class="content mt-3">
                        <div class="card">
                        <div class="card-body">
                        <p>Halo <b><?php echo $_SESSION['Username']; ?></b> Anda telah login sebagai <b><?php echo $_SESSION['Level']; ?></b>.</p>
                        </div>
                    </div>
                </div>
                <?php
                include'footer.php';
                ?>